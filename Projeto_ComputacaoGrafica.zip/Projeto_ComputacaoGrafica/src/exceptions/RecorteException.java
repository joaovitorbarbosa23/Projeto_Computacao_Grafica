package exceptions;

/**
 *
 */
public class RecorteException extends Exception {

	private static final long serialVersionUID = 1L;

	public RecorteException(String message) {
        super(message);
    }
    
}
